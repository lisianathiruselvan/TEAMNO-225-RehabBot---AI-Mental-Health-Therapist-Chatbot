// Variables for elements
const splashMusic = document.getElementById("splashMusic");
const splashScreen = document.querySelector(".splash-screen");
const mainContent = document.getElementById("mainContent");
const surveyButton = document.getElementById("sleepSurveyButton"); // Make sure this button exists in your HTML

// Function to play splash music and handle transition
function handleSplashScreen() {
    splashMusic.currentTime = 0; // Reset the music to the beginning
    splashMusic.play().catch(error => {
        console.error("Audio play failed:", error);
    });

    // Display main content and hide splash screen after 3 seconds
    setTimeout(() => {
        splashScreen.style.display = "none";
        mainContent.style.display = "block";
        splashMusic.pause(); // Stop the music once the splash screen disappears
        splashMusic.currentTime = 0; // Reset the music to the beginning
    }, 3000); // Adjust timing as needed
}

// Ensure the script runs after the DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    // Play the splash music and handle transition after user clicks anywhere
    document.body.addEventListener("click", function() {
        handleSplashScreen();
        document.body.removeEventListener("click", arguments.callee); // Remove the event listener after the first click
    });
});

// Check if survey button exists before adding event listener
if (surveyButton) {
    surveyButton.addEventListener("click", () => {
        const surveyWindow = document.getElementById("surveyWindow");
        const chatbotWindow = document.getElementById("chatbotWindow"); // Ensure this exists in your HTML

        if (surveyWindow) {
            resetSurveyForm(); // Clear the form each time it's opened
            surveyWindow.style.display = "block";
            if (chatbotWindow) {
                chatbotWindow.style.display = "none";
            }
        }
    });
}

// Reset survey form inputs
function resetSurveyForm() {
    const sleepHours = document.getElementById("sleepHours");
    const sleepQuality = document.getElementById("sleepQuality");
    const sleepConsistency = document.getElementById("sleepConsistency");
    const sleepStress = document.getElementById("sleepStress");
    const sleepRatingOutput = document.getElementById("sleepRatingOutput");

    if (sleepHours) sleepHours.value = "";
    if (sleepQuality) sleepQuality.value = "";
    if (sleepConsistency) sleepConsistency.value = "";
    if (sleepStress) sleepStress.value = "";
    if (sleepRatingOutput) sleepRatingOutput.innerHTML = ""; // Clear the output display
}

// Handle Survey Submission
document.getElementById("submitSurvey").addEventListener("click", () => {
    const sleepHours = document.getElementById("sleepHours").value;
    const sleepQuality = document.getElementById("sleepQuality").value;
    const sleepConsistency = document.getElementById("sleepConsistency").value;
    const sleepStress = document.getElementById("sleepStress").value;

    if (sleepHours && sleepQuality && sleepConsistency && sleepStress) {
        const sleepRating = calculateSleepRating(sleepHours, sleepQuality, sleepConsistency, sleepStress);
        document.getElementById("sleepRatingOutput").innerHTML = `Your Sleep Rating: ${sleepRating}/10 <br> ${generateSleepSuggestion(sleepRating)}`;
    } else {
        alert("Please complete all fields in the survey.");
    }
});

// Calculate Sleep Rating based on user inputs
function calculateSleepRating(hours, quality, consistency, stress) {
    let rating = 0;

    rating += Math.min(10, Math.max(0, parseInt(hours) - 5));
    if (quality === "Excellent") rating += 3;
    else if (quality === "Good") rating += 2;
    else if (quality === "Fair") rating += 1;
    if (consistency === "Very Consistent") rating += 2;
    else if (consistency === "Somewhat Consistent") rating += 1;
    if (stress === "Yes") rating -= 1;

    return Math.min(Math.max(rating, 0), 10);
}

// Generate Sleep Suggestion based on rating
function generateSleepSuggestion(rating) {
    if (rating >= 8) {
        return "Great job! Your sleep habits are healthy. Keep it up!";
    } else if (rating >= 5) {
        return "Your sleep is decent, but there's room for improvement. Aim for more consistent hours.";
    } else {
        return "Consider prioritizing sleep quality and consistency. A healthy sleep routine can improve your well-being.";
    }
}

// Close Survey Window
document.getElementById("closeSurvey").addEventListener("click", () => {
    const surveyWindow = document.getElementById("surveyWindow");
    if (surveyWindow) {
        surveyWindow.style.display = "none";
    }
});
